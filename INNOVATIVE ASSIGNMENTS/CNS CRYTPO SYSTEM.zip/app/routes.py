
from flask import current_app as app, render_template, request, jsonify, redirect, url_for
from . import db
from .models import SimulationResult
from .simulate import run_sample_simulation, summarize_result
import json

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    sims = SimulationResult.query.order_by(SimulationResult.created_at.desc()).limit(10).all()
    return render_template('dashboard.html', sims=sims)

@app.route('/simulate', methods=['POST'])
def simulate():
    payload = request.json or {}
    name = payload.get('name', 'Quick Simulation')
    params = payload.get('params', {})
    # run sample simulation (fast & deterministic)
    result = run_sample_simulation(params)
    summary = summarize_result(result)
    sim = SimulationResult(name=name, parameters=json.dumps(params), result_json=json.dumps(result))
    db.session.add(sim)
    db.session.commit()
    return jsonify({'status':'ok','id': sim.id, 'summary': summary, 'result': result})

@app.route('/simulation/<int:sim_id>')
def view_simulation(sim_id):
    sim = SimulationResult.query.get_or_404(sim_id)
    return render_template('report.html', sim=sim, result_json=sim.result_json)
