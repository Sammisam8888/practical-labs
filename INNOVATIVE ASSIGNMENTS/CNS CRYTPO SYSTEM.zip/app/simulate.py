
"""Simulation utilities for Cryptocurrency Network Security (CNS) project.
These are demonstrative models you can expand in your report:
- network_delay simulation
- node_failure / partition simulation
- double-spend risk estimation (toy model)
"""
import random, math, time

def run_sample_simulation(params):
    # params: { 'num_nodes': int, 'honest_ratio': float, 'tx_rate': float }
    num_nodes = int(params.get('num_nodes', 50))
    honest = float(params.get('honest_ratio', 0.8))
    tx_rate = float(params.get('tx_rate', 5.0))  # tx per second per node (toy)

    # simulate latencies (ms)
    latencies = [max(1.0, random.gauss(100, 20)) for _ in range(num_nodes)]
    # estimate connected components after random failures
    fail_prob = max(0.0, 1.0 - honest)
    failed = [1 for _ in range(int(num_nodes * fail_prob))]
    alive = num_nodes - len(failed)

    # double-spend risk estimate (toy): higher when confirmations slow & dishonest majority exists
    avg_latency = sum(latencies) / len(latencies)
    confirmation_time = max(0.5, avg_latency/1000.0 * 6)  # in seconds for 6 confirmations - toy
    dishonest_ratio = 1.0 - honest
    double_spend_risk = min(1.0, dishonest_ratio * (tx_rate/10.0) * (confirmation_time/2.0))

    # produce simple time-series of tx throughput
    duration = 30  # seconds of simulated timeline
    timeline = []
    for t in range(duration):
        # throughput fluctuates with random noise and node availability
        active = max(1, alive - int(0.05 * t))  # small churn
        throughput = active * tx_rate * max(0.1, 1.0 - random.random()*0.1)
        timeline.append({'t': t, 'throughput': throughput})

    return {
        'num_nodes': num_nodes,
        'honest_ratio': honest,
        'tx_rate': tx_rate,
        'avg_latency_ms': avg_latency,
        'alive_nodes': alive,
        'double_spend_risk': double_spend_risk,
        'timeline': timeline,
    }

def summarize_result(result):
    # create a short human-readable summary dict
    return {
        'nodes': result['num_nodes'],
        'alive': result['alive_nodes'],
        'avg_latency_ms': round(result['avg_latency_ms'],2),
        'double_spend_risk_pct': round(result['double_spend_risk']*100,2)
    }
