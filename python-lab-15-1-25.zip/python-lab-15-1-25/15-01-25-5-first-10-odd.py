#wap to print the first 10 odd numbers

print("First 10 odd numbers are : ")
for i in range(1,21,2):
    print(i,end=" ")