#wap to print the reverse of a word by taking user input

word=input("Enter a word : ")
print("The reverse of the given word is : ",word[::-1])
